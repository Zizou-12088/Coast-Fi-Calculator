
# Coast FI Calculator — Zizzi Investments

This is a Streamlit app you can deploy on Streamlit Community Cloud and embed on WordPress.

## Quick Deploy (Streamlit Cloud)
1) Create a new public GitHub repo.
2) Upload these files:
   - `streamlit_app.py`
   - `requirements.txt`
   - `.streamlit/config.toml`
3) Go to https://share.streamlit.io/ (Streamlit Community Cloud), connect GitHub, and pick your repo.
4) Set the entry point to `streamlit_app.py` and deploy.
5) You'll get a live URL like: `https://yourname-yourrepo.streamlit.app`

## WordPress Embed
Use a Custom HTML block on your site and paste:
```html
<iframe src="YOUR_STREAMLIT_APP_URL" width="100%" height="900" frameborder="0"></iframe>
```

## Local Run (optional)
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Customize Branding
Edit `.streamlit/config.toml` and the BRAND_* variables at the top of `streamlit_app.py`.
